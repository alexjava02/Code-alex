package com.alex.tp1.Metiers;
import java.math.BigInteger;


public class DVD extends Article {

    /**
     * La classe DVD définit les variables associées à un DVD et est en héritage de la classe Article
     *
     */

    private int isbnDVD;
    private String nomRealisateur;
    private String prenomRealisateur;

    /**
     * Constructeur de la classe DVD avec toutes ces variables
     * @param titre
     * @param prix
     * @param isbnDVD
     * @param nomRealisateur
     * @param prenomRealisateur
     */

    public DVD(String titre, double prix, int isbnDVD, String nomRealisateur, String prenomRealisateur) {
        super(titre, prix);
        this.isbnDVD = isbnDVD;
        this.nomRealisateur = nomRealisateur;
        this.prenomRealisateur = prenomRealisateur;
    }

    /**
     * Getter pour l'isbn du DVD
     * @return isbnDVD
     */

    public int getIsbnDVD() {
        return isbnDVD;
    }

    /**
     * Setter pour l'isbn du DVD
     * @param isbnDVD
     */

    public void setIsbnDVD(int isbnDVD) {
        this.isbnDVD = isbnDVD;
    }

    /**
     * Getter pour le nom du réalisateur
     * @return nomRealisateur
     */

    public String getNomRealisateur() {
        return nomRealisateur;
    }

    /**
     * Setter pour le nom du réalisateur
     * @param nomRealisateur
     */

    public void setNomRealisateur(String nomRealisateur) {
        this.nomRealisateur = nomRealisateur;
    }

    /**
     * Getter pour le prénom du réalisateur
     * @return prenomRealisateur
     */

    public String getPrenomRealisateur() {
        return prenomRealisateur;
    }

    /**
     * Setter du nom du réalisateur
     * @param prenomRealisateur
     */

    public void setPrenomRealisateur(String prenomRealisateur) {
        this.prenomRealisateur = prenomRealisateur;
    }

    /**
     * Méthode toString pour la classe DVD
     * @return isbnDVD, titre, prix, prenomRealisateur, nomRealisateur
     */

    @Override
    public String toString() {
        return "DVD ==> " +
                "Isbn : " + isbnDVD +
                ", Titre : " + getTitre() +
                ", Prix : " +getPrix() +
                ", Par : '" + prenomRealisateur + ' ' + nomRealisateur + '\'' +
                '}';
    }
}
