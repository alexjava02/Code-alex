package com.alex.tp1.Metiers;

public class Utilitaire {

    /**
     * Classe qui permet d'alléger le main en mettant certaine méthode dans cette classe et les appeller par le main
     */

    /**
     * Permet l'affichage du menu pour l'utilisateur
     */

    public static void afficherMenu(){
        System.out.println("Menu");
        System.out.println("===");
        System.out.println("1. Affichez la liste de tous les articles");
        System.out.println("2. Affichez la liste des DVD concernant un auteur");
        System.out.println("3. Ajoutez un DVD");
        System.out.println("4. Supprimez un article en fonction d'un auteur (ne pas faire)");
        System.out.println("5. Modifiez un article (ne pas faire");
        System.out.println("6. Supprimez toute la liste");
        System.out.println("0. Quitter");
        System.out.println("Entrez votre choix (1,2,3,4,5,6,0 pour quitter) : ");
    }
}
