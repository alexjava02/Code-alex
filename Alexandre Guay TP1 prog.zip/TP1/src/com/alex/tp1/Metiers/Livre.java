package com.alex.tp1.Metiers;

/**
 * Classe qui permet de définir les variables que contient un livre, tout en étant en héritage avec la classe Article
 */

public class Livre extends Article {

    private int isbn;
    private int nbPage;
    private String nomAuteur;
    private String prenomAuteur;

    /**
     * Constructeur de la classe Livre
     * @param titre
     * @param prix
     * @param isbn
     * @param nbPage
     * @param nomAuteur
     * @param prenomAuteur
     */


    public Livre(String titre, double prix, int isbn, int nbPage, String nomAuteur, String prenomAuteur) {
        super(titre, prix);
        this.isbn = isbn;
        this.nbPage = nbPage;
        this.nomAuteur = nomAuteur;
        this.prenomAuteur = prenomAuteur;
    }

    /**
     * Getter de l'isbn
     * @return isbn
     */

    public int getIsbn() {

        return isbn;
    }

    /**
     * Setter de l'isbn
     * @param isbn
     */

    public void setIsbn(int isbn) {

        this.isbn = isbn;
    }

    /**
     * Getter du nombre de page du livre
     * @return nbPage
     */

    public int getNbPage() {

        return nbPage;
    }

    /**
     * Setter du nombre de page du livre
     * @param nbPage
     */

    public void setNbPage(int nbPage) {

        this.nbPage = nbPage;
    }

    /**
     * Getter pour le nom de l'auteur
     * @return nomAuteur
     */

    public String getNomAuteur() {

        return nomAuteur;
    }

    /**
     * Setter pour le nom de l'auteur
     * @param nomAuteur
     */

    public void setNomAuteur(String nomAuteur) {

        this.nomAuteur = nomAuteur;
    }

    /**
     * Getter pour le prénom de l'auteur
     * @return prenomAuteur
     */

    public String getPrenomAuteur() {

        return prenomAuteur;
    }

    /**
     * Setter pour le prénom de l'auteur
     * @param prenomAuteur
     */

    public void setPrenom(String prenomAuteur) {

        this.prenomAuteur = prenomAuteur;
    }

    /**
     * Méthode toString pour l'affichage des infos entrées par l'utilisateur pour le livre
     * @return isbn, titre, prix, nbPage, prenomAuteur, nomAuteur
     */

    @Override
    public String toString() {
        return "Livre => " +
                "Isbn : " + isbn +
                ", Titre : " + getTitre() +
                ", Prix ($) : " +getPrix() +
                ", Nombres de pages : " + nbPage +
                ", Par : '" + prenomAuteur + ' ' + nomAuteur + '\'' +
                '}';
    }
}
