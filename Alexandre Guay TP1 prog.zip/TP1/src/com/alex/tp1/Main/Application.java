package com.alex.tp1.Main;
import com.alex.tp1.Metiers.*;
import java.util.Scanner;

/**
 * Programme qui permet de créer un magasin et d'y créer des articles
 * Les articles peuvent être des DVD et des livres
 * L'utlisateur peut choisir différentes options à partir d'un menu
 * Il peut afficher la liste d'article du magasin, afficher la liste des DVD concernant un auteur spécifique,
 * ajouter un DVD à la liste d'article et supprimer la liste des articles.
 *
 * @author Alexandre Guay
 * @since 21 avril 2022
 * @version 1.0
 *
 */


public class Application {
    public static void main(String[] args){

        /**
         * Classe application qui contient le Main du programme
         * L'utilisateur doit saisir sont choix dans le menu pour pouvoir faire ce qu'il désire
         */

        Scanner sc=new Scanner(System.in);
        Magasin magasinAlex = new Magasin();
        int choix, isbnDVD=0;
        Utilitaire menu = new Utilitaire();

        String nomRea = new String();
        String prenomRea = new String();
        String titreDVD = new String();
        String prenomReaRechercher = new String();
        String nomReaRechercher = new String();
        double prixDVD=0;

        magasinAlex.afficherNombreArticles();
        Utilitaire.afficherMenu();
        choix = sc.nextInt();

        while (choix != 0) {

                switch (choix) {
                    case 1:
                        magasinAlex.afficheListe();
                        break;
                    case 2:
                        magasinAlex.afficheDVD(nomReaRechercher, prenomReaRechercher);
                        break;
                    case 3:
                        magasinAlex.ajouterDVD(nomRea, prenomRea, titreDVD, prixDVD, isbnDVD);
                        break;
                    case 4:
                        magasinAlex.supprimerArticles();
                        break;
                    case 5:
                        magasinAlex.modifierArticle();
                        break;
                    case 6:
                        magasinAlex.supprimerListes();
                        break;
                    default:
                        System.out.println("Choix invalide");
                }
            System.out.println();
            Utilitaire.afficherMenu();
            choix = sc.nextInt();
        }


    }
}
