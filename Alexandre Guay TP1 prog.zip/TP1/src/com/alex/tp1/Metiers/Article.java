package com.alex.tp1.Metiers;

public class Article {

    /**
     * Classe Article qui permet de féinir ce qu'est un article et de l'envoyer en héritage à la classe DVD et Livre
     */
    private String getNomRealisateur;
    private int numRef;
    private String titre;
    private double prix;

    public Article() {
        this.numRef = numRef;
        this.prix = 0;
        this.titre = "titre inconnu";
    }

    /**
     * Constructeur de la classe article avec ses variables
     * @param titre
     * @param prix
     */

    public Article(String titre, double prix) {
        this.numRef = numRef;
        this.titre = titre;
        this.prix = prix;
    }

    /**
     * Getter du numéro de référence de l'article
     * @return numRef
     */

    public int getNumRef() {

        return numRef;
    }

    /**
     * Setter du numéro de référence de l'article
     * @param numRef
     */

    public void setNumRef(int numRef) {

        this.numRef = numRef;
    }

    /**
     * Getter pour le titre de l'article
     * @return titre
     */

    public String getTitre() {

        return titre;
    }

    /**
     * Setter pour le titre de l'article
     * @param titre
     */

    public void setTitre(String titre) {

        this.titre = titre;
    }

    /**
     * Getter pour le prix de l'article
     * @return
     */

    public double getPrix() {

        return prix;
    }

    /**
     * Setter pour le prix de l'article
     * @param prix
     */

    public void setPrix(double prix) {

        this.prix = prix;
    }

    /**
     * Méthode toString pour la classe Article
     * @return numRef, titre, prix
     */

    @Override
    public String toString() {
        return "Article{" +
                "numRef : " + numRef +
                ", titre : '" + titre + '\'' +
                ", prix ($) : " + prix +
                '}';
    }

    /**
     * Getter pour le get du nom du réalisateur
     * @return
     */

    public String getGetNomRealisateur() {
        return getNomRealisateur;
    }

    /**
     * Setter pour le get nom du réalisateur
     * @param getNomRealisateur
     */

    public void setGetNomRealisateur(String getNomRealisateur) {
        this.getNomRealisateur = getNomRealisateur;
    }
}
