package com.alex.tp1.Metiers;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * Cette classe Magasin permet de faire plusieurs choses en lien avec le magasin
 * Dont le remplir d'articles d'en ajouter ou d'en supprimer
 */


public class Magasin {

    static Scanner sc=new Scanner(System.in);

    private static List<Article> articlesMagasin;

    public Magasin() {
        this.articlesMagasin = new ArrayList<>();
        remplirMagasin();
    }

    /**
     * remplirMagasin permet de remplir le magasin avec des livres et des DVD
     */

    private void remplirMagasin() {
        Article article1 = new Livre("Voyage au centre de la terre", 90, 54654, 450, "Verne", "Jules");
        Article article2 = new Livre("À la plaque", 35, 56464, 80, "Larrivée", "Ricardo");
        Article article3 = new DVD("Prog", 45, 546464, "Lavigne", "Alex");
        Article article4 = new DVD("Avatar", 45, 54664, "Guay", "Alex");
        Article article5 = new DVD("Titanic", 20, 546546, "Guay", "Alex");
        Article article6 = new Livre("Programmation", 45, 54664, 300, "Guay", "Alex");
        articlesMagasin.add(article1);
        articlesMagasin.add(article2);
        articlesMagasin.add(article3);
        articlesMagasin.add(article4);
        articlesMagasin.add(article5);
        articlesMagasin.add(article6);
    }

    /**
     * Permet d'afficher la liste des articles du magasin
     * @return la liste d'articles du magasin
     */

    public void afficheListe() {
        if (articlesMagasin.isEmpty())
            System.out.println("La liste des articles est vide");
        else {
            for (Article article : articlesMagasin
            ) {
                System.out.println(article);
            }
        }
    }

    /**
     * Affiche le nombre d'articles qui sont dans le magasin
     */

    public static void afficherNombreArticles(){
        System.out.println("Magasin remplis de : " +articlesMagasin.size()+ " articles");
        System.out.println();
    }

    /**
     * Permet d'afficher tous les DVD qui sont dans la liste du magasin
     * @param nomReaRechercher
     * @param prenomReaRechercher
     * @return les messages de saisie
     */

    public static void afficheDVD(String nomReaRechercher, String prenomReaRechercher) {
        System.out.println("Entez le nom de l'auteur recherché : ");
        nomReaRechercher = sc.next();
        System.out.println("Entrez le prénom de l'auteur recherché : ");
        prenomReaRechercher = sc.next();

        for (int i=0; i<articlesMagasin.size(); i++){
            if (articlesMagasin.get(i) instanceof DVD){
                String nomTemp=((DVD)articlesMagasin.get(i)).getNomRealisateur();
                if (nomReaRechercher.equalsIgnoreCase(nomTemp)){
                    System.out.println(articlesMagasin.get(i));
                }
            }
        }

    }

    /**
     * Permet à l'utilisateur d'ajouter un DVD à la liste d'article du magasin
     * @param nomRea
     * @param prenomRea
     * @param titreDVD
     * @param prixDVD
     * @param isbnDVD
     * @return les messages de saisie
     */

    public static void ajouterDVD(String nomRea, String prenomRea, String titreDVD, double prixDVD, int isbnDVD) {
        System.out.println("==Données d'un DVD==");
        System.out.println("Entrez le nom du réalisateur : ");
        nomRea = sc.next();
        System.out.println("Entrez le prénom du réalisateur : ");
        prenomRea = sc.next();
        System.out.println("Entrez le titre du DVD : ");
        titreDVD = sc.next();
        System.out.println("Entrez le prix du DVD : ");
        prixDVD = sc.nextDouble();
        System.out.println("Entrez l'isbn du DVD : ");
        isbnDVD = sc.nextInt();
        Article article7 = new DVD(titreDVD, +prixDVD, +isbnDVD, nomRea, prenomRea);
        articlesMagasin.add(article7);
        System.out.println("Le DVD a bien été ajouté au magasin");
    }

    public static void supprimerArticles() {
        System.out.println("Ne pas faire");
    }

    public static void modifierArticle(){
        System.out.println("Ne pas faire");
    }

    /**
     * Permet de supprimer la liste d'article du magasin
     */

    public static void supprimerListes(){
        articlesMagasin.clear();
        System.out.println("Tous les articles ont été supprimer");
    }
}